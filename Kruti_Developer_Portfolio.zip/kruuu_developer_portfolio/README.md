# Kruti Sanon — Developer Portfolio

A responsive personal portfolio built with plain HTML, CSS, and JavaScript. No build tools or package installation are required.

## Run locally
1. Download and extract the ZIP.
2. Open the `kruuu_developer_portfolio` folder in VS Code.
3. Open `index.html` in a browser, or use the Live Server extension.

## Before publishing — important checklist
- [ ] Update the email, GitHub, and LinkedIn links in `script.js`.
- [ ] Confirm the name, college/degree wording, year, and all project descriptions are accurate.
- [ ] For each project, add its real GitHub repository and live demo link when available.
- [ ] Add real screenshots and measured results only when you have them.
- [ ] Remove or revise any skill you cannot confidently explain.
- [ ] Add a PDF resume if you have one ready.
- [ ] Check the website on both mobile and desktop.

## Project honesty
The portfolio currently uses designed preview illustrations for project cards. They are not screenshots of deployed products. Project descriptions are written as prototypes, studies, or areas in progress where appropriate. Do not present a project as deployed, validated, or complete unless that is true.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `kruti-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` (keep them in the repository root).
3. Open repository **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site and open the URL shown there.
7. Add the live URL to your LinkedIn profile under **Featured** and **Contact info**.

## LinkedIn tip
Upload the ZIP only if LinkedIn's current upload field accepts that file type. Usually, the better approach is to publish the site and add its URL to your Featured section. You can also upload a PDF portfolio/resume as a document.
